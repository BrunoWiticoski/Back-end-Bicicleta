export enum Generos {
  MASCULINO = 'M',
  FEMININO = 'F'
}