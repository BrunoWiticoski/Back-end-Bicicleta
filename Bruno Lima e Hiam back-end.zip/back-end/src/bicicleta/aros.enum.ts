export enum TamanhoArosEnum {
  A12 = 'ARO 12',
  A16 = 'ARO 16',
  A20 = 'ARO 20',
  A24 = 'ARO 24',
  A26 = 'ARO 26',
  A27 = 'ARO 27,5',
  A29 = 'ARO 29'
}